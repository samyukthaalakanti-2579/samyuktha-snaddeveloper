package com.example.snadservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SnadServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SnadServiceApplication.class, args);
	}

}
