package com.example.snadservice.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.example.snadservice.dto.Dto;
import com.example.snadservice.model.Model;
import com.example.snadservice.repository.Repository;


@Component
public class Service {
	@Autowired
	Repository rs;
	public void SaveMyData(Dto dto){
		Model m=new Model();
		m.setEmployee_id(dto.getEmployee_id());
		m.setEmployee_name(dto.getEmployee_name());
		m.setEmployee_project(dto.getEmployee_project());
		m.setEmployee_sal(dto.getEmployee_sal());
		rs.save(m);
	}
	 public List<Dto> getEmployeeRecords() {
	        Iterable<Model> m = rs.findAll();   
	        List<Dto>dto = new ArrayList<Dto>();
	        for(Model i:m)
	        {
	            dto.add(Dto.getDto(i));
	        }
	        return dto;
	    }
	 public List<Dto> getEmployeeByname(String employee_name) {
	        Iterable<Model> m = rs.findByEmployeeName(employee_name); 
	        List<Dto> dto = new ArrayList<Dto>();
	        for(Model i:m)
	        {
	            dto.add(Dto.getDto(i));
	        }
	        return dto;
	    }
	 public List<Dto> getEmployeenamebyc() {
	        Iterable<Model> m = rs.findByEmployeeNameByC(); 
	        List<Dto> dto = new ArrayList<Dto>();
	        for(Model i:m)
	        {
	            dto.add(Dto.getDto(i));
	        }
	        return dto;
	    }
	 public List<Dto> getEmployeesal() {
	        Iterable<Model> m = rs. findByEmployeesal(); 
	        List<Dto> dto = new ArrayList<Dto>();
	        for(Model i:m)
	        {
	            dto.add(Dto.getDto(i));
	        }
	        return dto;
	    }
	 public List<Dto> getEmployeesalbetween() {
	        Iterable<Model> m = rs. findByEmployeesalbetween(); 
	        List<Dto> dto = new ArrayList<Dto>();
	        for(Model i:m)
	        {
	            dto.add(Dto.getDto(i));
	        }
	        return dto;
	    }
	 
	 public void updateEmployeedata(Dto dto) {
		 Model m=new Model();
		    m.setEmployee_id(dto.getEmployee_id());
			m.setEmployee_name(dto.getEmployee_name());
			m.setEmployee_project(dto.getEmployee_project());
			m.setEmployee_sal(dto.getEmployee_sal());
			rs.save(m);
}		

}
