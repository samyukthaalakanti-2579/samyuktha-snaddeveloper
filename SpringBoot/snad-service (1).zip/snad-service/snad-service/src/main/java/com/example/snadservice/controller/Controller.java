package com.example.snadservice.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.snadservice.dto.Dto;
import com.example.snadservice.dto.ResponseWrapper;
import com.example.snadservice.service.Service;



@RestController
public class Controller {
	@Autowired
	Service service;
	
	@PostMapping(value = "/postEmployeedata")
	public ResponseWrapper postCustomerData(@RequestBody Dto dto, HttpServletRequest request,
			HttpServletResponse response) {
		ResponseWrapper rw = new ResponseWrapper(true);
		try {
			service.SaveMyData(dto);
		} catch (Exception e) {
			rw.setSuccess(false);
		}
		rw.setMessage("Inserted Successfully");
		return rw;
	}

	@GetMapping(value="/getEmployeedata")
    public ResponseWrapper getEmployeeData(HttpServletRequest request, HttpServletResponse response)
    {
        ResponseWrapper rw = new ResponseWrapper(true);
        try {
            List<Dto> listOfEmployees = service.getEmployeeRecords() ;
            rw.setData(listOfEmployees);
        }
        catch (Exception e)
        {
            rw.setSuccess(false);
        }
        rw.setMessage("List of Employees");

        return rw;
    }
	@GetMapping(value="/getEmployeedataByName/{name}")
    public ResponseWrapper getEmployeedataByName(@PathVariable String name,HttpServletRequest request, HttpServletResponse response)
    {
        ResponseWrapper rw = new ResponseWrapper(true);
        try {
            List<Dto> Employeedata = service.getEmployeeByname(name);
            rw.setData(Employeedata);
        }
        catch (Exception e)
        {
            rw.setSuccess(false);
        }
        rw.setMessage("List of Employees");

        return rw;
}
	@GetMapping(value="/getEmployeedataByNamec")
    public ResponseWrapper getEmployeenamebyc(HttpServletRequest request, HttpServletResponse response)
    {
        ResponseWrapper rw = new ResponseWrapper(true);
        try {
            List<Dto> Employeedatabynamec = service.getEmployeenamebyc();
            rw.setData(Employeedatabynamec);
        }
        catch (Exception e)
        {
            rw.setSuccess(false);
        }
        rw.setMessage("List of Employees");

        return rw;
}
	@GetMapping(value="/getEmployeesal")
    public ResponseWrapper getEmployeesal( HttpServletRequest request, HttpServletResponse response)
    {
        ResponseWrapper rw = new ResponseWrapper(true);
        try {
            List<Dto> Employeesal = service.getEmployeesal();
            rw.setData(Employeesal);
        }
        catch (Exception e)
        {
            rw.setSuccess(false);
        }
        rw.setMessage("List of Employees");

        return rw;
}
	@GetMapping(value="/getEmployeesalbetween")
    public ResponseWrapper getEmployeesalbetween( HttpServletRequest request, HttpServletResponse response)
    {
        ResponseWrapper rw = new ResponseWrapper(true);
        try {
            List<Dto> Employeesalbetween = service.getEmployeesalbetween();
            rw.setData(Employeesalbetween);
        }
        catch (Exception e)
        {
            rw.setSuccess(false);
        }
        rw.setMessage("List of Employees");

        return rw;
}
	
	@PutMapping(value="/updateEmployeedata/{employee_id}")
    public ResponseWrapper updateEmployeedata(@PathVariable int employee_id,@RequestBody Dto dto ,HttpServletRequest request, HttpServletResponse response)
    {
        ResponseWrapper rw = new ResponseWrapper(true);
        try {
        	dto.setEmployee_id(employee_id);
        	service.updateEmployeedata(dto);
        }
        catch (Exception e)
        {
            rw.setSuccess(false);
        }
        rw.setMessage("updated successfully");

        return rw;
}
}
