package com.example.snadservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.example.snadservice.model.Model;

public interface Repository extends JpaRepository <Model, Long> {
	@Query(value="select * from snad_employees where employee_name=?1", nativeQuery = true)
    List<Model> findByEmployeeName(String name);
	@Query(value="select * from snad_employees where employee_name likes 'c' ", nativeQuery = true)
    List<Model> findByEmployeeNameByC();
	@Query(value="select * from snad_employees where employee_sal<200000", nativeQuery = true)
    List<Model> findByEmployeesal();
	@Query(value="select * from snad_employees where employee_sal>100000 AND employee_sal<200000", nativeQuery = true)
    List<Model> findByEmployeesalbetween();

}

