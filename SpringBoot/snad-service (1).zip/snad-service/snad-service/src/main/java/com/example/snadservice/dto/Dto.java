package com.example.snadservice.dto;

import com.example.snadservice.model.Model;

public class Dto {
	private int employee_id;
	private String employee_name;
	private String employee_project;
	private long employee_sal;
	
	
	public int getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}
	public String getEmployee_project() {
		return employee_project;
	}
	public void setEmployee_project(String employee_project) {
		this.employee_project = employee_project;
	}
	public long getEmployee_sal() {
		return employee_sal;
	}
	public void setEmployee_sal(long employee_sal) {
		this.employee_sal = employee_sal;
	}
	public static Dto getDto(Model i) {

        Dto dto = new Dto();
       dto.setEmployee_id(i.getEmployee_id());
       dto.setEmployee_name(i.getEmployee_name());
       dto.setEmployee_project(i.getEmployee_project());
       dto.setEmployee_sal(i.getEmployee_sal());
       
        return dto;
    }
    
}
