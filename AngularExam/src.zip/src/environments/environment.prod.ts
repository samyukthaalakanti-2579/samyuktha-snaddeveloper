export const environment = {
  production: true,
  ApiUrl: "//testapi.skilllens.com/api" 
};
